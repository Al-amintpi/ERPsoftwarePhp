
			</div>
			 
			 
			<div class="footer-wrap pd-20 mb-20 card-box">
				Coder It Solution By <a href="https://coderitsolution.com" target="_blank">Ashiqur Rahman</a>
			</div>
		</div>
	</div>
	<!-- js -->
	<script src="assets/vendors/scripts/core.js"></script>
	<script src="assets/vendors/scripts/script.min.js"></script>
	<script src="assets/vendors/scripts/process.js"></script>
	<script src="assets/vendors/scripts/layout-settings.js"></script>
	<script src="assets/src/plugins/jQuery-Knob-master/jquery.knob.min.js"></script>
	<script src="assets/src/plugins/highcharts-6.0.7/code/highcharts.js"></script>
	<script src="assets/src/plugins/highcharts-6.0.7/code/highcharts-more.js"></script>
	<script src="assets/src/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
	<script src="assets/src/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="assets/vendors/scripts/dashboard2.js"></script>
	<!-- tables add -->
	<script src="assets/src/plugins/datatables/js/jquery.dataTables.min.js"></script>
	<script src="assets/src/plugins/datatables/js/dataTables.bootstrap4.min.js"></script>
	<script src="assets/src/plugins/datatables/js/dataTables.responsive.min.js"></script>
	<script src="src/plugins/datatables/js/responsive.bootstrap4.min.js"></script>
	<!-- buttons for Export datatable -->
	<script src="assets/src/plugins/datatables/js/dataTables.buttons.min.js"></script>
	<script src="assets/src/plugins/datatables/js/buttons.bootstrap4.min.js"></script>
	<script src="assets/src/plugins/datatables/js/buttons.print.min.js"></script>
	<script src="assets/src/plugins/datatables/js/buttons.html5.min.js"></script>
	<script src="assets/src/plugins/datatables/js/buttons.flash.min.js"></script>
	<script src="assets/src/plugins/datatables/js/pdfmake.min.js"></script>
	<script src="assets/src/plugins/datatables/js/vfs_fonts.js"></script>
	<!-- Datatable Setting js -->
	<script src="assets/vendors/scripts/datatable-setting.js"></script></body>

	 
</body>
</html> 